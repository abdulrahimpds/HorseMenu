#include "HandleNetGameEvent.hpp"
#include "CrashGuard.hpp"

#include "game/features/Features.hpp"
#include "game/pointers/Pointers.hpp"
#include "game/backend/Players.hpp"   // YimMenu::Player class and player database
#include "game/backend/Self.hpp"      // YimMenu::Self for local player
#include "core/hooking/BaseHook.hpp"
#include "core/hooking/DetourHook.hpp"

namespace YimMenu {
namespace Hooks {

bool Protections::HandleNetGameEvent(rage::netEventMgr* eventMgr,
                                     CNetGamePlayer* sourcePlayer,
                                     CNetGamePlayer* targetPlayer,
                                     NetEventType type,
                                     int index,
                                     int handledBits,
                                     std::int16_t unk,
                                     rage::datBitBuffer* buffer)
{
    // Use SafeZone to protect against crashes in event handling
    CrashGuard::SafeZone("HandleNetGameEvent", [&]()
    {
        // Make a local copy of the event buffer to safely read data without modifying original
        rage::datBitBuffer new_buffer = *buffer;

        // Logging of events if enabled and event type is known
        if (Features::_LogEvents.GetState() && static_cast<size_t>(type) < g_NetEventsToString.size()) {
            LOG(INFO) << "NETWORK_EVENT: " 
                      << g_NetEventsToString[static_cast<size_t>(type)]
                      << " from " << (sourcePlayer ? sourcePlayer->GetName() : "UNKNOWN");
        }

        // 1. Protection: NETWORK_DESTROY_VEHICLE_LOCK_EVENT (ensure the target is actually a vehicle)
        if (type == NetEventType::NETWORK_DESTROY_VEHICLE_LOCK_EVENT) {
            auto net_id = new_buffer.Read<uint16_t>(13);
            if (auto object = Pointers::GetNetObjectById(net_id)) {
                // If the object ID is not a vehicle, block this event (likely crash attempt)
                if (!IsVehicleType(static_cast<NetObjType>(object->m_ObjectType))) {
                    LOG(WARNING) << "Blocked mismatched destroy-vehicle-lock event from " 
                                 << (sourcePlayer ? sourcePlayer->GetName() : "Unknown");
                    // Mark the source player as detected modder
                    if (sourcePlayer) {
                        Player(sourcePlayer).AddDetection(Detection::TRIED_CRASH_PLAYER);
                    }
                    // Acknowledge the event without processing to prevent the crash
                    Pointers::SendEventAck(eventMgr, nullptr, sourcePlayer, targetPlayer, index, handledBits);
                    return;  // skip calling the original handler
                }
            }
        }

        // 2. Protection: EXPLOSION_EVENT (block explosions from modders if enabled)
        if (type == NetEventType::EXPLOSION_EVENT && sourcePlayer) {
            if (Features::_BlockExplosions.GetState() || 
                (Player(sourcePlayer).IsValid() && Player(sourcePlayer).GetData().m_BlockExplosions)) {
                LOG(WARNING) << "Blocked explosion event from " << sourcePlayer->GetName();
                Pointers::SendEventAck(eventMgr, nullptr, sourcePlayer, targetPlayer, index, handledBits);
                return;
            }
        }

        // 3. Protection: NETWORK_PTFX_EVENT (block particle effects if enabled)
        if (type == NetEventType::NETWORK_PTFX_EVENT && sourcePlayer) {
            if (Features::_BlockPtfx.GetState() || 
                (Player(sourcePlayer).IsValid() && Player(sourcePlayer).GetData().m_BlockParticles)) {
                LOG(WARNING) << "Blocked particle effects event from " << sourcePlayer->GetName();
                Pointers::SendEventAck(eventMgr, nullptr, sourcePlayer, targetPlayer, index, handledBits);
                return;
            }
        }

        // 4. Protection: NETWORK_CLEAR_PED_TASKS_EVENT (block remote clearing of local tasks if enabled)
        if (type == NetEventType::NETWORK_CLEAR_PED_TASKS_EVENT && sourcePlayer &&
            Features::_BlockClearTasks.GetState()) {
            auto net_id = new_buffer.Read<uint16_t>(13);
            // If the target of the clear tasks event is the local player’s ped, block it
            if (net_id == Self::GetPed().GetNetworkObjectId()) {
                LOG(WARNING) << "Blocked clear-ped-tasks event targeting local player from " 
                             << sourcePlayer->GetName();
                Pointers::SendEventAck(eventMgr, nullptr, sourcePlayer, targetPlayer, index, handledBits);
                return;
            }
        }

        // 5. Protection: SCRIPT_COMMAND_EVENT (remote native injection; block if enabled)
        if (type == NetEventType::SCRIPT_COMMAND_EVENT && sourcePlayer && 
            Features::_BlockScriptCommand.GetState()) {
            // Optionally log details of the script command (if a function exists to do so)
            LogScriptCommandEvent(sourcePlayer, new_buffer);
            LOG(WARNING) << "Blocked remote script command from " << sourcePlayer->GetName();
            Pointers::SendEventAck(eventMgr, nullptr, sourcePlayer, targetPlayer, index, handledBits);
            if (sourcePlayer) {
                Player(sourcePlayer).AddDetection(Detection::MODDER_EVENTS);
            }
            return;
        }

        // 6. Special handling: GIVE_CONTROL_EVENT (track the player who initiated object synchronization)
        if (type == NetEventType::GIVE_CONTROL_EVENT && sourcePlayer) {
            Protections::SetSyncingPlayer(sourcePlayer);
            // (No blocking; just record who is giving control of an object)
        }

        // Call the original game handler for any events not explicitly blocked
        BaseHook::Get<HandleNetGameEvent, DetourHook<decltype(&HandleNetGameEvent)>>()->Original()(
            eventMgr, sourcePlayer, targetPlayer, type, index, handledBits, unk, buffer
        );
    }); // end SafeZone

    // This hook function returns void, so no return value is needed here
    return true;  // (Returning a dummy value or nothing as appropriate for the hook signature)
}

}} // namespace YimMenu::Hooks::Protections
