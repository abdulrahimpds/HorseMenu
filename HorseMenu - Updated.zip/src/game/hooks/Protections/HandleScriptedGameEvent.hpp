#pragma once

#include "network/CNetGamePlayer.hpp"
#include "network/CScriptedGameEvent.hpp"
#include "game/rdr/Enums.hpp"   // Contains ScriptEvent enum definitions

namespace YimMenu::Protections {

    // Hook for handling incoming scripted game events
    bool HandleScriptedGameEvent(CScriptedGameEvent* event, CNetGamePlayer* src, CNetGamePlayer* dst);

} // namespace YimMenu::Protections
