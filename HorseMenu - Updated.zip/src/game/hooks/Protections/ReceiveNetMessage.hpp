#pragma once

#include "network/CNetGamePlayer.hpp"
#include "network/CNetworkScSession.hpp"
#include "network/InFrame.hpp"
#include "rage/datBitBuffer.hpp"
#include "game/rdr/Enums.hpp"  // Defines NetMessageType, etc.

namespace YimMenu::Protections {

    // Hook for receiving network messages (packets)
    bool ReceiveNetMessage(void* a1, rage::netConnectionManager* ncm, rage::netConnection::InFrame* frame);

} // namespace YimMenu::Protections
