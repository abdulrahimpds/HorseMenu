#include "CrashGuard.hpp"
#include "core/hooking/DetourHook.hpp"
#include "core/hooking/BaseHook.hpp"
#include "ReceiveNetMessage.hpp"

#include "game/features/Features.hpp"
#include "game/frontend/Notifications.hpp"
#include "game/backend/Self.hpp"
#include "game/backend/Players.hpp"
#include "game/pointers/Pointers.hpp"
#include "util/Chat.hpp"           // for chat or LOG utilities
#include "core/frontend/widgets/imgui_colors.h"  // for logging color constants (if needed)

#include <array>
#include <network/CNetGamePlayer.hpp>
#include <network/CNetworkScSession.hpp>
#include <network/InFrame.hpp>
#include <network/rlGamerHandle.hpp>
#include <network/rlScPeerConnection.hpp>
#include <rage/datBitBuffer.hpp>
#include <format>
#include <string>
#include <algorithm>

namespace YimMenu {
namespace Hooks {

    // Helper to read the NetMessageType from a datBitBuffer
    static bool GetMessageType(NetMessageType& type, rage::datBitBuffer& buffer) {
        // The message header contains a magic '0x2F' (Rockstar protocol) and a type field
        if (buffer.Read<int>(14) != '2F') {
            return false;
        }
        bool extended = buffer.Read<bool>(1);
        type = buffer.Read<NetMessageType>(extended ? 16 : 8);
        return true;
    }

    // Helper to log raw packet data for debugging (skipping certain large or frequent message types)
    static void LogFrame(rage::netConnection::InFrame* frame) {
        rage::datBitBuffer buffer(frame->m_Data, frame->m_Length);
        buffer.m_FlagBits |= 1u;  // allow reading multiple times
        NetMessageType msgType;
        GetMessageType(msgType, buffer);
        // List of message types to ignore in logging (too frequent or not useful)
        static constexpr auto unloggables = std::to_array<NetMessageType>({
            NetMessageType::CLONE_SYNC,
            NetMessageType::PACKED_CLONE_SYNC_ACKS,
            NetMessageType::PACKED_EVENTS,
            NetMessageType::PACKED_RELIABLES,
            NetMessageType::PACKED_EVENT_RELIABLES_MSGS,
            NetMessageType::NET_ARRAY_MGR_UPDATE,
            NetMessageType::NET_ARRAY_MGR_UPDATE_ACK,
            NetMessageType::NET_ARRAY_MGR_SPLIT_UPDATE_ACK,
            NetMessageType::NET_TIME_SYNC,
            NetMessageType::SCRIPT_JOIN,
            NetMessageType::SCRIPT_JOIN_ACK,
            NetMessageType::SCRIPT_JOIN_HOST_ACK,
            NetMessageType::SCRIPT_HANDSHAKE,
            NetMessageType::SCRIPT_BOT_HANDSHAKE_ACK
        });
        // Only log if this message type is not in the ignore list
        if (std::find(unloggables.begin(), unloggables.end(), msgType) == unloggables.end()) {
            // Determine source player name or address
            std::string srcInfo = std::format("{}.{}.{}.{}:{}", 
                                 frame->m_Address.m_external_ip.m_field1,
                                 frame->m_Address.m_external_ip.m_field2,
                                 frame->m_Address.m_external_ip.m_field3,
                                 frame->m_Address.m_external_ip.m_field4,
                                 frame->m_Address.m_external_port);
            // Translate message type to name if known
            std::string msgName = std::format("0x{:X}", static_cast<int>(msgType));
            if (auto it = Data::g_MessageTypes.find(static_cast<int>(msgType)); it != Data::g_MessageTypes.end()) {
                msgName = it->second;
            }
            // Attempt to match message ID to a player in the session (for P2P sources)
            auto session = (*Pointers::ScSession)->m_SessionMultiplayer;
            if (session && frame->m_MsgId != -1) {
                for (int i = 0; i < 32; ++i) {
                    if (auto player = session->GetPlayerByIndex(i)) {
                        if (player->m_SessionPeer && player->m_SessionPeer->m_Connection && 
                            player->m_SessionPeer->m_Connection->m_MessageId == frame->m_MsgId) {
                            if (player->m_HasGamerInfo) {
                                srcInfo = player->m_GamerInfo.m_Name;
                            }
                            break;
                        }
                    }
                }
            }
            // Log the packet info (length, connection id, etc.)
            LOGF(VERBOSE, "PKT: {} [len: {}, cxn_id: {}] from {}", 
                 msgName, frame->m_Length, frame->m_ConnectionId, srcInfo);
        }
    }

    bool Protections::ReceiveNetMessage(void* a1, rage::netConnectionManager* ncm, rage::netConnection::InFrame* frame)
    {
        bool result = false;
        CrashGuard::SafeZone("ReceiveNetMessage", [&]()
        {
            // Only intercept fully received frames
            if (frame->GetEventType() != rage::netConnection::InFrame::EventType::FrameReceived) {
                // Not a normal received frame, just call original
                result = BaseHook::Get<Protections::ReceiveNetMessage, DetourHook<decltype(&Protections::ReceiveNetMessage)>>()
                             ->Original()(a1, ncm, frame);
                return;
            }

            // If the frame has no data or zero length, let the original handle it
            if (frame->m_Data == nullptr || frame->m_Length == 0) {
                result = BaseHook::Get<Protections::ReceiveNetMessage, DetourHook<decltype(&Protections::ReceiveNetMessage)>>()
                             ->Original()(a1, ncm, frame);
                return;
            }

            // Optionally, log the raw packet if logging is enabled
            if (Features::_LogPackets.GetState()) {
                LogFrame(frame);
            }

            // Prepare to read the message type and possibly identify the sender
            rage::datBitBuffer buffer(frame->m_Data, frame->m_Length);
            buffer.m_FlagBits |= 1u;
            NetMessageType msgType;
            CNetworkScSessionPlayer* senderPlayer = nullptr;
            auto session = (*Pointers::ScSession)->m_SessionMultiplayer;

            // Identify the sending player (if any) by matching the message ID or address
            if (session) {
                if (frame->m_MsgId != -1) {
                    // If message ID is set, find the player with matching message ID
                    for (int i = 0; i < 32; ++i) {
                        if (auto player = session->GetPlayerByIndex(i)) {
                            if (player->m_SessionPeer && player->m_SessionPeer->m_Connection && 
                                player->m_SessionPeer->m_Connection->m_MessageId == frame->m_MsgId) {
                                senderPlayer = player;
                                break;
                            }
                        }
                    }
                } else {
                    // If no message ID, use IP matching for connectionless packets (if connection type indicates P2P)
                    if (frame->m_Address.m_connection_type == 1) { // direct connection
                        for (int i = 0; i < 32; ++i) {
                            if (auto player = session->GetPlayerByIndex(i)) {
                                if (player->m_SessionPeer && player->m_SessionPeer->m_Connection) {
                                    auto addr = Pointers::GetPeerAddressByMessageId(ncm, player->m_SessionPeer->m_Connection->m_MessageId);
                                    if (addr && addr->m_external_ip.m_packed == frame->m_Address.m_external_ip.m_packed) {
                                        senderPlayer = player;
                                        break;
                                    }
                                }
                            }
                        }
                    } else if (frame->m_Address.m_connection_type == 2) { // relay connection
                        for (int i = 0; i < 32; ++i) {
                            if (auto player = session->GetPlayerByIndex(i)) {
                                // (In a relay scenario, additional logic could be added here if needed)
                                if (player->m_SessionPeer) {
                                    // Simplified: assume relay doesn't allow us to easily identify sender beyond MsgId
                                }
                            }
                        }
                    }
                }
            }

            // Now process the packet by reading its type
            if (!GetMessageType(msgType, buffer)) {
                // If message type could not be read properly, call original and exit
                result = BaseHook::Get<Protections::ReceiveNetMessage, DetourHook<decltype(&Protections::ReceiveNetMessage)>>()
                             ->Original()(a1, ncm, frame);
                return;
            }

            // (Optional) Additional protections based on message type could go here
            // e.g., block certain malicious packet types if identified

            // If lobby lock is enabled, prevent new session join requests
            if (*Pointers::IsSessionStarted && Features::_LockLobby.GetState()) {
                if (msgType == NetMessageType::CONNECT_REQUEST) {
                    // Block incoming connection requests when lobby is locked
                    LOG(WARNING) << "Blocked CONNECT_REQUEST message while lobby lock is active.";
                    result = true; // pretend we've handled it (do not call original, dropping the packet)
                    return;
                }
            }

            // Finally, call the original function to handle the message normally (if not blocked)
            result = BaseHook::Get<Protections::ReceiveNetMessage, DetourHook<decltype(&Protections::ReceiveNetMessage)>>()
                         ->Original()(a1, ncm, frame);
        });

        return result;
    }

}} // namespace YimMenu::Hooks::Protections
