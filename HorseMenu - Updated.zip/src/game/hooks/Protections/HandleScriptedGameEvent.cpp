#include "CrashGuard.hpp"
#include "core/hooking/DetourHook.hpp"
#include "core/hooking/BaseHook.hpp"
#include "HandleScriptedGameEvent.hpp"

#include "game/features/Features.hpp"
#include "game/frontend/Notifications.hpp"  // For Notifications::Show (if used for UI warnings)
#include "game/backend/Self.hpp"
#include "game/backend/Players.hpp"
#include <format>
#include <string>

namespace YimMenu {
namespace Hooks {

bool Protections::HandleScriptedGameEvent(CScriptedGameEvent* event, CNetGamePlayer* src, CNetGamePlayer* dst)
{
    bool result = false;
    CrashGuard::SafeZone("HandleScriptedGameEvent", [&]()
    {
        // If logging of script events is enabled, log the details for debugging
        if (Features::_LogScriptEvents.GetState()) {
            std::string scriptArgs = "{ ";
            // The event data is an array of 8-byte values
            for (std::size_t i = 0; i < event->m_DataSize / 8; ++i) {
                if (i != 0) scriptArgs += ", ";
                scriptArgs += std::to_string(static_cast<int>(event->m_Data[i]));
            }
            scriptArgs += " }";
            LOG(VERBOSE) << "Script Event from " << (src ? src->GetName() : "UNKNOWN")
                         << ":\n\tArgs: " << scriptArgs 
                         << "\n\tScript Hash: 0x" << std::hex << event->m_ScriptId.m_ScriptHash
                         << std::dec << "\n\tHasMetadataIdx: " << (event->m_HasScriptMetadataIdx ? "YES" : "NO")
                         << "\n\tID Overridden: " << (event->m_ScriptIdOverridden ? "YES" : "NO");
        }

        // Determine the script event type (the first data element is usually an event identifier)
        ScriptEvent evntId = static_cast<ScriptEvent>(static_cast<int>(event->m_Data[0]));
        switch (evntId) {
            case ScriptEvent::SCRIPT_EVENT_PERSONA_HONOR:
                // Block honor changes if the event indicates a negative honor action and the protection is on
                if (event->m_Data[4] == 2 && Features::_BlockHonorEvent.GetState()) {
                    Notifications::Show("Protections", 
                        std::format("Blocked honor manipulation from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;  // mark as handled (blocked)
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_NOTORIETY_FORCE_PASSIVE:
                // Force defensive mode (passive) event
                if (event->m_Data[8] == 2 && Features::_BlockDefensive.GetState()) {
                    Notifications::Show("Protections", 
                        std::format("Blocked forced Defensive Mode from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_NOTORIETY_FORCE_NOT_PASSIVE_HORSE:
                // Force offensive mode on horse event (target player is m_Data[1])
                if (event->m_Data[1] == Self::GetPlayer().GetId() && Features::_BlockOffensive.GetState()) {
                    Notifications::Show("Protections", 
                        std::format("Blocked forced Offensive Mode from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_NOTORIETY_PRESS_CHARGES:
                // Press charges event (various flags in data[4] and data[11])
                if ((event->m_Data[11] && event->m_Data[4] == 2) || 
                    (event->m_Data[4] == 3 && Features::_BlockPressCharges.GetState())) {
                    Notifications::Show("Protections", 
                        std::format("Blocked press charges from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_PARLAY:
                // Start Parlay (data[4] == 3) or End Parlay (data[4] == 5)
                if (event->m_Data[4] == 3 && Features::_BlockStartParlay.GetState()) {
                    Notifications::Show("Protections", 
                        std::format("Blocked start parlay from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                if (event->m_Data[4] == 5 && Features::_BlockEndParlay.GetState()) {
                    Notifications::Show("Protections", 
                        std::format("Blocked end parlay from {}", src->GetName()), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_TICKER_MESSAGE:
                // Ticker messages (chat/feed spam) – use rate limiter in PlayerData
                if (Player(src).GetData().m_TickerMessageRateLimit.Process() && Features::_BlockTickerSpam.GetState()) {
                    if (Player(src).GetData().m_TickerMessageRateLimit.ExceededLastProcess()) {
                        LOGF(NET_EVENT, WARNING, "Blocked ticker spam (event id: {}) from {}", event->m_Data[4], src->GetName());
                    }
                    result = true;
                    return;
                }
                break;

            case ScriptEvent::SCRIPT_EVENT_NET_STABLE_MOUNT:
                // Stable mount events (like forcing someone onto a mount or similar)
                if (event->m_Data[1] == Self::GetPlayer().GetId() && Features::_BlockStableEvents.GetState()) {
                    // Show which specific stable event was blocked using lookup table if available
                    Notifications::Show("Protections", 
                        std::format("Blocked stable event from {} ({} )", 
                                    src->GetName(), 
                                    Data::g_StableMountEvent[event->m_Data[4]].second), 
                        NotificationType::Warning);
                    result = true;
                    return;
                }
                break;

            default:
                // Other script events are not explicitly handled here
                break;
        }

        // If not blocked by any of the above cases, call the original handler to process the event
        result = BaseHook::Get<Protections::HandleScriptedGameEvent, DetourHook<decltype(&Protections::HandleScriptedGameEvent)>>()
                     ->Original()(event, src, dst);
    });

    return result;
}

}} // namespace YimMenu::Hooks::Protections
