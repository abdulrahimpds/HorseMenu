#pragma once

#include <cstdint>
#include "rage/datBitBuffer.hpp"
#include "network/CNetGamePlayer.hpp"

// Forward declare netEventMgr from Rage networking
namespace rage {
    class netEventMgr;
}

// Include definitions for NetEventType (and other related enums)
#include "game/rdr/Enums.hpp"

namespace YimMenu::Protections {

    // Hook function for network game events (declaration)
    void HandleNetGameEvent(rage::netEventMgr* eventMgr,
                             CNetGamePlayer* sourcePlayer,
                             CNetGamePlayer* targetPlayer,
                             NetEventType type,
                             int index,
                             int handledBits,
                             std::int16_t unk,
                             rage::datBitBuffer* buffer);

} // namespace YimMenu::Protections
