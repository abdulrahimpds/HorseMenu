#pragma once

#include <eh.h>
#include <stdexcept>
#include <functional>
#include <sstream>
#include "util/Chat.hpp"    // Logging/Chat utilities for output

// Define a custom exception type for crash protection
namespace YimMenu {
    class CrashException : public std::runtime_error {
    public:
        explicit CrashException(const std::string& message) : std::runtime_error(message) {}
        explicit CrashException(const char* message) : std::runtime_error(message) {}
    };
}

namespace YimMenu::CrashGuard {

    // Structured Exception Translator (converts SEH to C++ exception)
    inline void SehTranslator(unsigned int code, EXCEPTION_POINTERS* /*info*/) {
        std::ostringstream oss;
        oss << "SEH Exception occurred with code 0x" << std::hex << code;
        // Throw as CrashException so we can catch it in our hooks
        throw YimMenu::CrashException(oss.str());
    }

    // Initialize the SEH translator once
    inline void InitializeSehTranslator() {
        static bool initialized = false;
        if (!initialized) {
            // Note: Using SEH translator requires /EHa in MSVC for full compatibility
            _set_se_translator(SehTranslator);
            initialized = true;
        }
    }

    // SafeZone executes the passed function and catches both C++ and translated SEH exceptions.
    inline void SafeZone(const char* label, const std::function<void()>& fn) {
        InitializeSehTranslator();
        try {
            fn();  // Execute the protected code
        }
        catch (const std::exception& e) {
            // Log any C++ exceptions (including CrashException thrown by SehTranslator)
            LOG(WARNING) << "[CRASH PROTECTION] Exception caught in " << label << ": " << e.what();
        }
        catch (...) {
            // Catch any other non-standard exceptions
            LOG(WARNING) << "[CRASH PROTECTION] Unknown exception caught in " << label;
        }
    }

} // namespace YimMenu::CrashGuard
