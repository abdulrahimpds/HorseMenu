#include "core/commands/BoolCommand.hpp"
#include "core/hooking/DetourHook.hpp"
#include "game/hooks/Hooks.hpp"
#include "game/pointers/Pointers.hpp"
#include "CrashGuard.hpp"   // For CrashException definition and translator
#include "util/Joaat.hpp"
#include "util/StrToHex.hpp"
#include "util/Protobufs.hpp"

#include <network/netServerMessages.hpp>


namespace YimMenu::Features {
    // Define toggle for logging server messages
    BoolCommand _LogServerMessages("logservermessages", "Log Server Messages", "Log incoming server messages");
    // Define toggle/feature for unlimited items (for example, intercepting "UseItems" message)
    BoolCommand _UnlimitedItems("unlimiteditems", "Unlimited Items", "Prevent item consumption (infinite items)");
}

namespace YimMenu::Hooks
{
	bool Protections::ReceiveServerMessage(void* a1, rage::netRpcReader* reader)
	{
		if (Features::_LogServerMessages.GetState())
		{
			LOG(INFO) << __FUNCTION__ << ": " << reader->GetName() << ": " << BytesToHexStr((unsigned char*)reader->GetContext()->m_Data, reader->GetContext()->m_Size);
		}

		return BaseHook::Get<ReceiveServerMessage, DetourHook<decltype(&ReceiveServerMessage)>>()->Original()(a1, reader);
	}

	bool Protections::SerializeServerRPC(rage::netRpcBuilder* builder, void* a2, const char* message, void* def, void* structure, const char* RPCGuid, void* a7)
	{
		bool ret = BaseHook::Get<SerializeServerRPC, DetourHook<decltype(&SerializeServerRPC)>>()->Original()(builder, a2, message, def, structure, RPCGuid, a7);

		if (Features::_LogServerMessages.GetState())
		{
			LOG(INFO) << __FUNCTION__ << ": " << message << ":";
			PrintProtoBuffer(builder->GetData(), builder->GetSize(), def); // TODO this seems broken
		}

		if (Joaat(message) == "UseItems"_J && Features::_UnlimitedItems.GetState())
			return false;

		return ret;
	}

	void Protections::DeserializeServerMessage(rage::netRpcReaderContext* ctx, void* def, void* structure)
	{
		// Hook for a server RPC deserialize function, with crash protection
		try {
			// Call original function to deserialize server message
			BaseHook::Get<DeserializeServerMessage, DetourHook<decltype(&DeserializeServerMessage)>>()
				->Original()(ctx, def, structure);
		}
		catch (const YimMenu::CrashException&) {
			// If a structured exception occurred during deserialization, it’s caught here
			LOG(WARNING) << "[Protections::DeserializeServerMessage] Exception caught and prevented a crash during message parsing.";
			// We swallow the exception to stop the crash propagation
		}
		// No return value (original function likely void), just exit safely
	}
}
