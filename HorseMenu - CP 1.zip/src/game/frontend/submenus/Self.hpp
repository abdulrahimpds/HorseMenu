#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Self : public Submenu
	{
	public:
		Self();
	};
}