#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Players : public Submenu
	{
	public:
		Players();
	};
}