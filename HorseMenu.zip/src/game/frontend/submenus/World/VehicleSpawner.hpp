#pragma once

namespace YimMenu::Submenus
{
	void RenderVehicleSpawnerMenu();
}